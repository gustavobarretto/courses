package com.is_challenge.is_challenge.apiStreaming.exception;

public class ScoreNotFoundException extends RuntimeException{
    public ScoreNotFoundException(String messege){
        super(messege);
    }
}
