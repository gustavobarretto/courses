package com.is_challenge.is_challenge.apiStreaming.entity;

public class Comment {
}
